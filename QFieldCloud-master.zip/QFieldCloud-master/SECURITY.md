# Security Policy

## Supported Versions

On https://qfield.cloud we always run the latest stable release.


## Reporting a Vulnerability

At OPENGIS.ch we take security very seriously, if you found a vulnerability, please get in touch with security@qfield.org.

We'll get back at you as soon as possible after analising your report.
